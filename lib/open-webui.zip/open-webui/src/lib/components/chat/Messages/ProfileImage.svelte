<script lang="ts">
	export let src = '/user.png';
</script>

<div class=" mr-4">
	<img {src} class=" max-w-[28px] object-cover rounded-full" alt="profile" draggable="false" />
</div>
