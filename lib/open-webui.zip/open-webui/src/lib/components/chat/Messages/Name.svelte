<div class=" self-center font-bold mb-0.5 capitalize line-clamp-1">
	<slot />
</div>
